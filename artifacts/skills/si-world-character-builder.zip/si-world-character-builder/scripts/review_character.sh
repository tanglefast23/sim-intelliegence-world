#!/bin/sh
set -eu

if [ "$#" -ne 3 ]; then
  echo "usage: review_character.sh <repo-path> <character-id> <output-root>" >&2
  exit 2
fi

character_repo=$1
character_id=$2
character_output=$3

cd "$character_repo"
npm run typecheck
npm run art:atlas
npx tsx scripts/art/build-character-feature-review.ts \
  --character "$character_id" \
  --output-root "$character_output"

echo "$character_repo/$character_output/$character_id-feature-review-6x.png"
