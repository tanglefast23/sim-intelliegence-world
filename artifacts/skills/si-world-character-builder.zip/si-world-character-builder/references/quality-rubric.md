# Final-render character quality rubric

Judge the decoded atlas cell after contour, hair, accessories, and held items. Do not judge hidden base layers.

## Hair

- Require a distinct silhouette that matches the brief.
- Require base, highlight, and shadow values when hair is present.
- Arrange highlights and shadows as connected planes that show flow and lighting.
- Change the silhouette and value planes for rear and profile views.
- Reject noise-like isolated dots and large flat unshaded rectangles.

## Eyes and brows

- Keep paired front eyes equal in scale and construction unless the brief requires occlusion.
- Use one correctly placed eye in each profile.
- Keep pupils facing the direction of travel.
- Draw readable brows that support the expression.
- Preserve glasses around the eye construction instead of deleting one eye accidentally.

## Mouth and facial hair

- Draw a visible mouth that suits the expression.
- Place moustaches, beards, scarves, collars, and masks intentionally.
- Do not let an accessory erase the mouth by accident.
- Record intentional mouth occlusion in the final evidence.

## Hands

- Show both small hands in front when the outfit exposes them.
- Show the near hand in each profile.
- Use at least a skin base plus a highlight or shade when space permits.
- Keep hands separate from outfit accents.

## Direction

- Draw a true rear view without facial pixels.
- Draw true profiles with one eye, nose projection, mouth, near hand, and hair mass behind the face.
- Rotate asymmetrical hair and accessories logically.
- Reject compressed-front side views.

## Accessories

- Preserve the signature accessory in every view where it should be visible.
- Reposition the accessory for depth and direction.
- Keep it away from eyes and mouth unless occlusion is intentional.
- Keep the accessory readable at native 1x.

## Acceptance

- Inspect all four views at 6x and native 1x.
- Compare feature quality against the protagonist.
- Continue iterating while any material defect remains.
- Treat 9.7/10 as a high visual bar, not a geometry-presence calculation.
