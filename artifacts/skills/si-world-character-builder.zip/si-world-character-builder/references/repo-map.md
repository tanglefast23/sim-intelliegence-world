# SI World character-art repository map

- `scripts/art/character-look-roster.ts`: character descriptions, palettes, hair styles, outfits, and signature features.
- `scripts/art/character-source.ts`: front face, expressions, hair, body, hands, and identity commands.
- `scripts/art/lateral-legs.ts`: authored left profile and mirrored or adjusted right profile.
- `scripts/art/rear-frame.ts`: rear anatomy, rear hair shape, and rear hair lighting.
- `scripts/art/protagonist-reference.ts`: accepted hero reference frames.
- `scripts/art/build-world-atlas.ts`: production atlas assembly.
- `scripts/art/build-character-feature-review.ts`: focused hero-versus-character 6x sheet.
- `scripts/art/build-full-cast-review.ts`: full-cast direction comparison sheet.
- `scripts/art/character-style-score.ts`: rendered-feature quality report. Verify that it measures final cells before trusting scores.
- `scripts/art/__tests__/full-cast-art.test.ts`: shared character-art and direction gates.
- `assets/generated/world-atlas.png`: production atlas used by the game.
- `assets/source/art/revision-*-pixel-hashes.json`: exact pixel baseline for the current art revision.
- `artifacts/phase-24/art-quality/`: visual review evidence.
