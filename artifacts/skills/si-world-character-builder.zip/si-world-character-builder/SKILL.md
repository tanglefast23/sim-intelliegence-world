---
name: si-world-character-builder
description: This skill should be used when creating or redesigning a Sim Intelligence World pixel character from a user description. It gathers appearance preferences, authors production-ready front, rear, left, and right views, preserves readable face and accessory placement, and loops rendered 6x reviews until the character closely matches the protagonist's feature quality.
---

# SI World Character Builder

Create one distinctive 24x30 SI World character with complete directional art. Use the protagonist as the quality reference, not as a costume template.

## 1. Inspect the active repository

Confirm the checkout, branch, worktree state, and generated atlas before editing. Preserve unrelated changes.

Read these project files completely:

- `scripts/art/character-look-roster.ts`
- `scripts/art/character-source.ts`
- `scripts/art/lateral-legs.ts`
- `scripts/art/rear-frame.ts`
- `scripts/art/protagonist-reference.ts`
- `scripts/art/build-character-feature-review.ts`
- `references/quality-rubric.md` in this skill
- `references/repo-map.md` in this skill

## 2. Gather the character description

Ask for one compact description when the user has not supplied enough detail. Request:

- name and role;
- skin tone;
- hair color, length, texture, and flow;
- eye and brow character;
- mouth or facial-hair character;
- outfit shape and colors;
- one signature accessory;
- body shape or silhouette;
- personality cues that should influence pose or expression.

Do not ask again for details already present. Make reversible visual assumptions for omitted details and state them briefly.

## 3. Write the character brief

Translate the description into a short four-view contract before coding:

- front: face, brows, paired eyes, mouth, both hands, outfit, accessory;
- rear: back hair structure, outfit back, rear accessory position;
- left: one profile eye, nose, mouth, near hand, hair volume behind the face;
- right: mirrored anatomy with asymmetric hair and accessories intentionally reoriented;
- lighting: connected highlight and shadow planes that describe form;
- occlusion: allow genuine hair or accessories to cover features only when the design requires it.

Keep the identity readable at native 1x and inspect at nearest-neighbor 6x.

## 4. Author all four views

Add the roster entry first. Reuse the shared face, body, palette, and rendering helpers.

Author or extend these parts:

- front hair silhouette plus connected `h` highlight and `K` shadow planes;
- rear hair depth and flow, never copied front facial pixels;
- left profile with a single eye, nose, mouth, near hand, and rear hair volume;
- right profile with correct asymmetry and accessory orientation;
- brows and mouth appropriate to the character;
- small visible hands with skin highlight and shade;
- accessories placed outside the mouth and eyes unless intentional occlusion is part of the brief.

Never create side views by merely squeezing the front image. Never accept large flat unshaded hair rectangles.

## 5. Run the rendered review loop

Run `scripts/review_character.sh <repo-path> <character-id> <output-root>` from this skill.

Inspect the generated 6x PNG with the image viewer. Apply the quality rubric feature by feature.

For every iteration:

1. Name one largest visual defect.
2. Make one or two focused changes.
3. Regenerate the atlas and 6x review.
4. Inspect front, rear, left, and right pixels.
5. Repeat until no material defect remains.

Do not use hidden source geometry as visual proof. Grade the final atlas cells after every overlay.

## 6. Verify production use

Run the focused art tests, TypeScript, deterministic art check, and packaged local smoke required by the repository.

Confirm:

- all four atlas cells are present;
- left and right are true profiles;
- front eyes remain balanced unless intentionally occluded;
- brows, mouth, and hands remain readable;
- hair contains connected highlight and shadow planes in every applicable direction;
- accessory placement follows the brief;
- the packaged game loads the regenerated atlas.

## 7. Deliver evidence

Provide the 6x feature-review PNG and the full-cast comparison PNG. Report observed defects fixed, tests run, package provenance, and any intentional occlusion.

Do not report a numeric score unless the scorer measures final rendered feature cells and the screenshot supports the result.
